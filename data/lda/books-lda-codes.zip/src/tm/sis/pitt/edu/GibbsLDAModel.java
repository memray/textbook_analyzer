package tm.sis.pitt.edu;

import java.util.Vector;

import common.sis.pitt.edu.Corpus;
import common.sis.pitt.edu.TDocument;

/**
 * 
 * @author shuguang
 *PhD @ Univ. of Pittsburgh
 */
public class GibbsLDAModel {
	   //W:Number of Vocabulary Words
	   //D:Number of Document
	   //A:Number of Author
	   //T: Number of Topic
	   public int numberOfTerm=0;
	   public int numberOfDocument=0;
	   public int numberOfTopic=0;
	   public Randoms random;
		
		//z[d][w]:Topic assignment for each individual word
		//D = NumberOfDocumet in each Corpus
		//W = NumberOfWord in each Document
		public Vector<Integer>[] z;
		
		//nw:word-topic count matrix
		//nd:topic-document count matrix
		//nwsum: number of words from the w-th entry in vocabulary assigned to topic t, 
		//        excluding topic assignment to word wdi (w-th word can appear in many documents)
		//ndsum: number of words assigned to topic t excluding topic assignment to word wdi
		public int nw[][];
		public int nd[][];
		public int nwsum[];
		public int ndsum[];
		
		//alpha, beta
		public double alpha;
		public double beta;
		
		//theta, phi
		public double theta[][];
		public double phi[][];
		
		//p[k]=p(z_i|z_-i,w)
		public double p[];
		
		private Corpus c;
		
		public GibbsLDAModel(Corpus c, int K){
			this.numberOfTopic=K;
			this.numberOfTerm=c.getNumberofTerms();
			this.numberOfDocument=c.getNumberofDocs();
			this.alpha=50.0 / this.numberOfTopic;
			this.beta=0.01;
			this.c=c;
			this.random=new Randoms();
			this.initialModel();
		}
		
		private void initialModel(){
			//cwt: W*T Matrix Number of times word w has been assigned to topic j
			//cta: A*T matrix, number of times a word from author a has been assigned to topic j
			//cwtsum:total number of words has been assigned to topic j
			//ctasum: total topics that have been assigned to author a
			nw = new int[this.numberOfTerm][this.numberOfTopic];			
			nd = new int[this.numberOfDocument][this.numberOfTopic];
			nwsum = new int[this.numberOfTopic];
			ndsum = new int[this.numberOfDocument];
			
			//z(d,w):D*W Vector Matrix
			//x(a,w):A*W Vector Matrix
			///New z, x
			z = new Vector[this.numberOfDocument];
			
			//Initial Model States (cwt, cta, cwtsum, ctasum)
			//Set all the count variables into zero
			this.initZero(nw);
			this.initZero(nd);
			this.initZero(nwsum);
			this.initZero(ndsum);
			
			//Initial p[k]=p(z_i|z_-i,w)
			p = new double[this.numberOfTopic];
			
			//Initializing Z			
			for(int d = 0;d <= this.numberOfDocument-1; d++){
	            //Get Document Length
				TDocument doc = this.c.getDocs().get(d);
				int len = doc.getDocLength();
				z[d] = new Vector<Integer>();
				
				for(int n=0;n<=len-1;n++){
					//Randomly Generate a topic
					int topic = random.nextInt(this.numberOfTopic);
					
					//Assign Topic Value into Z(d,w), w can be represented into index of z[d]
					z[d].add(topic);
					
					nw[doc.getWord(n)][topic]++;
					nwsum[topic]++;					
					nd[d][topic]++;
					ndsum[d]++;
				}
			}
			
			this.phi=new double[this.numberOfTerm][this.numberOfTopic];
			this.theta=new double[this.numberOfDocument][this.numberOfTopic];
		}
		
		private void initZero(int[] a){
			for(int i=0;i<=a.length-1;i++)
				a[i]=0;
		}
		
		private void initZero(int[][] a){
			for(int i=0;i<=a.length-1;i++)
				for(int j=0;j<=a[i].length-1;j++)
					a[i][j]=0;
		}

}
