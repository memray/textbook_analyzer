package tm.sis.pitt.edu;

import java.util.Comparator;
import java.util.TreeMap;
import java.util.Map.Entry;

import common.sis.pitt.edu.Corpus;
import common.sis.pitt.edu.TDocument;
import common.sis.pitt.edu.Writer;

/**
 * 
 * @author shuguang
 * PhD student @ University of Pittsburgh
 */
public class GibbsLDA {
	
	private int numberOfTopic;
	private int numberOfIteration;
	private Corpus c;
	private GibbsLDAModel model;
	private String fileSuffix;
	
    public GibbsLDA(int numberOfTopic,double beta, double alpha,
    		int numberOfIteration, Corpus c, String fileSuffix){
		this.numberOfTopic=numberOfTopic;
		this.numberOfIteration=numberOfIteration;
		this.c=c;
		this.fileSuffix= fileSuffix; 
		this.initGM();
        this.estimate();
	}
	
	//Random Initialization
	private void initGM(){
		this.model = new GibbsLDAModel(this.c,this.numberOfTopic);	
	}
	
	private void estimate(){
		for(int iter=1;iter<=this.numberOfIteration;iter++){
			System.out.println("Iteration " + iter +"/"+this.numberOfIteration+" Times");
				
			//For each document
		    int D=model.numberOfDocument;
			for(int d=0;d<=D-1;d++){
				TDocument doc=c.getDocs().get(d);
				int dl = doc.getDocLength();
				//for each word
				for(int n=0;n<=dl-1;n++){
					//z_i=z[d][w], x_i=x[d][w]
					//Sampling z_i, x_i from p(z_i, x_i|z_-i,, x_-i, w)
					this.GibbsSampling(d, n, doc);
				}//end for each word in document			
			 }//end for each document in corpus
		   }//end iterations
		
		this.computePhi();
		this.computeTheta();
		this.saveModel();
		
	}
	
	private void GibbsSampling(int d, int n, TDocument doc){
    	//Get the former assigned topic;
		int topic=model.z[d].get(n);
		int wIndex=doc.getWord(n);

		//Decrease count in four arrays
		//cwt, cta, cwtsum, ctasum
		model.nw[wIndex][topic]--;
		model.nwsum[topic]--;
		model.nd[d][topic]--;
		model.ndsum[d]--;
		
		//Multi-nomial sampling according to p[]=p(z_i|z_-i,w)
		double Wbeta = model.numberOfTerm * model.beta;
		double Talpha = model.numberOfTopic * model.alpha;
			
		for(int k=0; k <= model.numberOfTopic-1; k++)	
			model.p[k] = ( ( model.nw[wIndex][k] + model.beta ) / (model.nwsum[k] + Wbeta ) ) 
			                 * ( (model.nd[d][k] + model.alpha) / ( model.ndsum[d] + Talpha ) );
		
		//Sample topic index from P: Using Inverse Transform Sampling Method by given CDF
		//From: http://en.wikipedia.org/wiki/Inverse_transform_sampling
		// The problem that the inverse transform sampling method solves is as follows:
		//     Let X be a random variable whose distribution can be described by the cumulative distribution function F.
		//	   We want to generate values of X which are distributed according to this distribution.
		// The inverse transform sampling method works as follows:
		//     Generate a random number u from the standard uniform distribution in the interval [0,1].(in this example, cdf is not normalized, so we can generate { u * cdf[k-1] } )
		//	   Compute the value x such that F(x) = u. (In this algorithm, the first time bigger than u is adopted to determine u)
		//	   Take x to be the random number drawn from the distribution described by F.
		for(int k = 1; k <= model.numberOfTopic-1; k++) {
			model.p[k] += model.p[k-1];
		}
		double u = Math.random() * model.p[model.numberOfTopic-1];
		for(topic = 0;topic <= model.numberOfTopic-1; topic++){
			if(model.p[topic]>u)
				break;
		}
		
		//Update Z 
		model.z[d].set(n, topic);
				
		// add newly estimated z_i to count variables
		model.nw[wIndex][topic]++;
		model.nwsum[topic]++;
		model.nd[d][topic]++;
		model.ndsum[d]++;
	}

	private void computePhi(){
	for(int w=0;w<=model.numberOfTerm-1;w++)
		for(int t=0;t<=model.numberOfTopic-1;t++)
		   model.phi[w][t] = (model.nw[w][t] + model.beta) / (model.nwsum[t] + model.numberOfTerm * model.beta);
	}

	private void computeTheta(){
	for(int a=0;a<=model.numberOfDocument-1;a++)
		for(int t=0;t<=model.numberOfTopic-1;t++)
			model.theta[a][t]= ( model.nd[a][t] + model.alpha ) / ( model.ndsum[a] + model.numberOfTopic * model.alpha );
	}

	private void saveModel(){
	String phiFile = "dataset/books-lda/" + model.numberOfTopic + "-final-" + fileSuffix + ".phi";
	String thetaFile = "dataset/books-lda/" + model.numberOfTopic + "-final-" + fileSuffix + ".theta";
	String termTopic = "dataset/books-lda/" + model.numberOfTopic + "-final-" + fileSuffix + ".t";
	
	StringBuilder sbPhi = new StringBuilder("");
	StringBuilder sbTheta = new StringBuilder("");
	
	//Save Phi Model
	for(int w=0;w<=model.numberOfTerm-1;w++){
		for(int t=0;t<=model.numberOfTopic-1;t++){
			sbPhi.append(model.phi[w][t]+"\t");	
		}
		sbPhi.append("\r\n");
		if(w%50==0) {
			Writer.write(phiFile, sbPhi.toString());
			sbPhi=new StringBuilder("");
			System.out.println(w + "/" + (model.numberOfTerm - 1) + ":Wrting Theta");
		}
	}
	Writer.write(phiFile, sbPhi.toString());
	System.out.println("Write Phi Successfully");
	
	//Save Theta Model
	for(int a=0;a<=model.numberOfDocument-1;a++){
		for(int t=0;t<=model.numberOfTopic-1;t++){
			double model_theta=model.theta[a][t];
			
			if(model_theta>0.00) 
				sbTheta.append(model.theta[a][t]+"\t");
			else 
				sbTheta.append(" \t");	
			
		}
		sbTheta.append("\r\n");
		
		if(a%50 == 0){
			Writer.write(thetaFile, sbTheta.toString());
			sbTheta=new StringBuilder("");
			System.out.println(a + "/" + (model.numberOfDocument-1)+":Wrting Phi");
		}
	}
	Writer.write(thetaFile, sbTheta.toString());
	System.out.println("Write Theta Successfully");
	
	//Save Author-Topic model
	for(int t=0;t<=model.numberOfTopic-1;t++){
		StringBuilder sbTopicTerm = new StringBuilder("");
		StringBuilder sbTopicDocument = new StringBuilder("");
		
		//Get TopicVocabularycMap & TopicDocumentMap
		TreeMap<Double,String> TopicDocumentMap = new TreeMap<Double,String>(new DecreaseComparator());
		TreeMap<Double,String> TopicVocabularycMap = new TreeMap<Double,String>(new DecreaseComparator());
		for(int a=0;a<=model.numberOfDocument-1;a++)		TopicDocumentMap.put(model.theta[a][t], a+"");
		for(int w=0;w<=model.numberOfTerm-1;w++) TopicVocabularycMap.put(model.phi[w][t], this.c.vocabularyIdValue.get(w+""));
		
        int max=20;
        int index=0;
		for(Entry<Double, String> m : TopicDocumentMap.entrySet()){
			if((++index)<max) sbTopicDocument.append(m.getValue()+";");
		}			
				
		index=0;
		for(Entry<Double, String> m : TopicVocabularycMap.entrySet()){
			if((++index)<max) sbTopicTerm.append(m.getValue()+"("+m.getKey()+")"+";      ");
		}			
		Writer.write(termTopic, sbTopicTerm.toString() + "\t" + sbTopicDocument.toString() + "\r\n");
		System.out.println("Write Topc Term " + t + "/" + (model.numberOfTopic-1));
	}		
	
	System.out.println("Write Top 20 Term-Topic Successfully");
}



	public static class DecreaseComparator implements Comparator {
		public int compare(Object element1, Object element2) {
			double lower1 = Double.parseDouble(element1.toString());
			double lower2 =	Double.parseDouble(element2.toString());
			return (lower1>lower2)?-1:((lower1==lower2)?0:1);
		}
	}


	public GibbsLDAModel getModel(){
		return this.model;
	}

}
