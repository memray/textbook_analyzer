package tm.sis.pitt.edu;

import common.sis.pitt.edu.Corpus;
import common.sis.pitt.edu.loadCorpus;

/**
 * Entry for Gibbs Sampling based LDA.
 * 
 * @author shuguang
 *
 */
public class LDAEntry {
	
	public static void main(String args[]){
		
		int[] topics = {10, 50, 100, 150, 200};
		String[] corpa = "high;low;medium".split(";");
		
//		int topics[] = {10};
		for(int numberOfTopic : topics) {
			for(String corpus : corpa) {
				String corpusFile = "dataset/books-lda/corpus-merged-" + corpus + ".txt";
				Corpus c = new loadCorpus(corpusFile).getCorpus();
				int numberOfIteration = 2000;
				double beta = 0.01;
				double alpha= 50.0 / numberOfTopic;
				new GibbsLDA(numberOfTopic, beta, alpha, numberOfIteration, c, corpus);
			}
			
		}
	}
}