package dataset.sis.pitt.edu;

import java.io.File;

import common.sis.pitt.edu.FileUtil;
import common.sis.pitt.edu.Reader;
import common.sis.pitt.edu.Writer;

public class BookDataset {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Reads a directory.
//		File folder = new File("dataset/books/");
//		File[] listOfFiles = folder.listFiles();
//		
//		for(File file : listOfFiles) {
//			String content  = Reader.read(file.toString(), "content");
//			Writer.write("dataset/corpus-books.txt",
//			    file.toString().replace("dataset\\books\\", "").replace(".html", "") +
//			    "\t" + content.trim() + "\r\n");
//		}
		
		String[] toBeMergedFiles = {"dataset/books-lda/corpus-books.txt", "dataset/books-lda/corpus-sigir-medium.txt"};
		FileUtil.merge(toBeMergedFiles, "dataset/books-lda/corpus-merged-medium.txt");
		
	}
}
