package dataset.sis.pitt.edu;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import common.sis.pitt.edu.Mysql;
import common.sis.pitt.edu.Reader;
import common.sis.pitt.edu.Writer;

public class DatasetGenerator {
	
	public static HashMap<String, Integer> getCitationCounts() {
		HashMap<String, Integer> citations = new HashMap<String, Integer>();
		for(String line : Reader.read("dataset/article_citations.txt")) {
			String articleId = line.split("\t")[0];
			int citationCount = Integer.parseInt(line.split("\t")[5]);
			citations.put(articleId, citationCount);
		}
		
		return citations;
	}
	
	public void generate() throws SQLException {
		int startYear = 2009;
		int endYear = 2015;
		
		HashMap<String, Integer> citationCount = DatasetGenerator.getCitationCounts();
		//read citation count
		Connection conn = Mysql.getConn("acm");	
		Statement st = conn.createStatement();
		ResultSet rs = null;
//		String sql = "SELECT article_id,Acm_Article_Title, Acm_Article_Abstract FROM acm_article " + 
//		    "WHERE Acm_Conference_id IN ( SELECT acm_conference_id FROM acm_conference_name" +
//				" WHERE acm_conference_name = 'SIGIR') AND art_pub_year >= "
//		          + startYear + " AND art_pub_year <= " + endYear + "";
		String sql = "SELECT article_id,Acm_Article_Title, Acm_Article_Abstract FROM acm_article " + 
			    "WHERE Acm_Conference_id IN ( SELECT acm_conference_id FROM acm_conference_name" +
					" WHERE acm_conference_name = 'SIGIR') ";
//		System.out.println(sql);
		rs = st.executeQuery(sql);
		while(rs.next()){
			String article_id = rs.getString("article_id");
			
			int citations = citationCount.containsKey(article_id) ? citationCount.get(article_id) : 0;
			if(citations < 3) {
				String art_title =  rs.getString("Acm_Article_Title").replace("\\", "");
				String art_abstract = rs.getString("Acm_Article_Abstract").replace("\\", "");
				Writer.write("dataset/books-lda/corpus-sigir-low" + ".txt", article_id + "\t" +
				    art_title.trim() + " " + art_abstract.trim() + "\r\n");	
			}
		}
		rs.close();
		st.close();
		conn.close();
	}
	
	public void generateUsingFullText() {
		File folder = new File("dataset/ir-full-text/");
		File[] listOfFiles = folder.listFiles();
		for(File file : listOfFiles) {
			String content  = Reader.read(file.toString(), "content");
			Writer.write("dataset/corpus-full-text.txt",
			    file.toString().replace("dataset\\ir-full-text\\", "").replace(".txt", "") +
			    "\t" + content.trim() + "\r\n");	
		}
	}

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		
		new DatasetGenerator().generate();
	}

}
