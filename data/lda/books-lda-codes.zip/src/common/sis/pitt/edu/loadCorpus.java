package common.sis.pitt.edu;

/**
 * 
 * @author shuguang
 *PhD @ Univ. of Pittsburgh
 */
public class loadCorpus {
	
	private String dataset;
	private Corpus c;
	
	public loadCorpus(String dataset){
		this.dataset=dataset;
		this.load();
	}
	
	private void load(){
		//Read Corpus Successful
		c = new Corpus(this.dataset);
	}
	
	public Corpus getCorpus(){
		return this.c;
	}

}
