package common.sis.pitt.edu;

import java.util.Vector;
/**
 * 
 * @author shuguang
 * @word stores the word index in vocabulary
 * @authors stores authors for this document
 */
public class TDocument {
	
	private Vector<Integer> word;
	public Vector<Integer> authors;
	public String type;
	public String group;
	public String docContent;
	
	public TDocument(){
		
	}

	/**
	 * @return word
	 */
	public Vector<Integer> getWord() {
		return word;
	}
	
	/**
	 * @param index:word index
	 * @return word index in vocabualry
	 */
	public int getWord(int index){
		return this.word.get(index);
	}

	public void setWord(Vector<Integer> word) {
		this.word = word;
	}

	public Vector<Integer> getAuthors() {
		return authors;
	}
	
	public int getAuthors(int index){
		return this.authors.get(index);
	}

	public void setAuthors(Vector<Integer> authors) {
		this.authors = authors;
	}
	
	public int getDocLength(){
		return this.word.size();
	}
	
	public int[] getAuthorInt(){
		int[] authorInt=new int[this.authors.size()];
		for(int i=0;i<this.authors.size();i++)	authorInt[i]=this.authors.get(i);
		return authorInt;
	}

	public String getDocContent() {
		return docContent;
	}

	public void setDocContent(String docContent) {
		this.docContent = docContent;
	}
}

