package common.sis.pitt.edu;

public class Config {

	private String datasetPrefix = "";

	public String getDatasetPrefix() {
		return datasetPrefix;
	}

	public void setDatasetPrefix(String datasetPrefix) {
		this.datasetPrefix = datasetPrefix;
	}
	
}
