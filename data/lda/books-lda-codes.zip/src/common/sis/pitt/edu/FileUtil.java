package common.sis.pitt.edu;

public class FileUtil {

	public static void merge(String[] fileNames, String outputFile) {
		for(String fileName : fileNames) {
			for(String content : Reader.read(fileName)) {
				Writer.write(outputFile, content + "\r\n");
			}
		}
	}

}
