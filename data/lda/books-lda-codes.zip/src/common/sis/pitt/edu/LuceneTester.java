package common.sis.pitt.edu;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.PorterStemFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import org.apache.lucene.util.Version;

public class LuceneTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_33);
	     Reader r = new StringReader("semi_final");
	     TokenStream ts = analyzer.tokenStream("content", r);
	 
	     PorterStemFilter ps = new PorterStemFilter(ts);
	     ps.addAttribute(TermAttribute.class);
	     
	     try
	     {
	       while (ps.incrementToken()) {
	         TermAttribute ta = (TermAttribute)ps.getAttribute(TermAttribute.class);
	         String s = ta.term().toString();
	         System.out.println(s);
	       }
	     }
	     catch (IOException localIOException)
	     {
	     }

	}

}
