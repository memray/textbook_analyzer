package common.sis.pitt.edu;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Vector;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.PorterStemFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import org.apache.lucene.util.Version;

/**
 * @author shuguang Han
 * PhD from University of Pittsburgh
 */
public class Corpus {
	
	/**
	 * Variables
	 * @ docs: ArrayList<Document>, each element is a document
	 * @ numberOfDocs: total number of documents
	 * @ numberOfTerms: total number of terms in Vocabulary
	 * @ dataset: dataset file location
	 * @ vocabulary: HashMap that stores Key & Value for words in Vocabulary
	 * @ vocabularyStringList:  Array that stores words in Vocabulary
	 * 
	 * Methods
	 * @Corpus:Construction Methods
	 * @readCorpus:Iteratively traversing all documents in the given directory
	 * @readFile:Read each file in each document
	 * @splitDocument:split <doc></doc> in each file
	 */
	public ArrayList<TDocument> docs=new ArrayList<TDocument>();
	public int numberofDocs=0;
	public int numberofTerms=0;
	public String dataset;
	public int numberOfTokens=0;
	
	//Words is a HashMap that contains all word in the Corpus
	//Vocabulary to VocabularyID
	public HashMap<String, String> vocabulary=new HashMap<String, String>();
	public HashMap<String, String> vocabularyIdValue=new HashMap<String, String>();	
	
	public Vector<Integer> docSize=new Vector<Integer>();
	private HashSet<String> domainstoplist = new HashSet<String>();
	
	public Corpus(String datasetFolder){
	  this.dataset=	datasetFolder;
	  try {
		  this.loadDomainStop();
		  this.readTXTFile();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void loadDomainStop(){
		
		ArrayList<String> domainstop = common.sis.pitt.edu.Reader.read("dataset/stopword/en.txt");
		for(String s : domainstop) {
			domainstoplist.add(s);
		}
		
	}
	
	//Read XML files
	private void readTXTFile() throws Exception{
		//Read the XML file
		FileInputStream fis = new FileInputStream(this.dataset);
		InputStreamReader Inputreader = new InputStreamReader(fis, "utf-8");
		BufferedReader br = new BufferedReader(Inputreader);		
		String line = new String();
		while((line = br.readLine()) != null)	{
			String olddocid = line.split("\t")[0];
			String text = "";
			if(line.split("\t").length > 1) text = line.split("\t")[1].trim();
	        this.processEachDocument(text, olddocid);
		}
		br.close();
		Inputreader.close();
		fis.close();
	}
	
	private void processEachDocument(String doc, String olddocid){
		
		TDocument document=new TDocument();	
	    //Processing Document
	    this.processingDocument(doc, document);
	    
		this.docs.add(document);
		this.docSize.add(document.getDocLength());
		this.numberofDocs++;		
	}
	
	private void processingDocument(String doc, TDocument document){
		 Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_33);
	     Reader r = new StringReader(doc.replace("_", " ").replace("-", "_"));
	     TokenStream ts = analyzer.tokenStream("content", r);
	 
	     PorterStemFilter ps = new PorterStemFilter(ts);
	     ps.addAttribute(TermAttribute.class);
	 
	     Vector<Integer> doc_word_vocabulary_id = new Vector<Integer>();
	     try
	     {
	       while (ps.incrementToken()) {
	         TermAttribute ta = (TermAttribute)ps.getAttribute(TermAttribute.class);
	         String s = ta.term().toString();
	         
	         s = getFormalString(s);
	 
	         if (!s.equals(""))
	         {
	           this.numberOfTokens += 1;
	 
	           if (!this.vocabulary.containsKey(s)) {
	             int size = this.vocabulary.size();
	             this.vocabulary.put(s, size + "");
	             this.vocabularyIdValue.put(size + "", s);
	             this.numberofTerms += 1;
	           }
	           
	           doc_word_vocabulary_id.add(Integer.parseInt(this.vocabulary.get(s)));
	         }
	       }
	     }
	     catch (IOException localIOException)
	     {
	     }
	 
	     document.setWord(doc_word_vocabulary_id);
	     document.setDocContent(doc);
	}
	
	private String getFormalString(String s) {
	     s = s.toLowerCase();
	     if (this.domainstoplist.contains(s)) s = "";
	     s = s.replace(",", "").replace(";", "").replace(":", "").replace("(", "").replace(")", "");
	     s = s.replace("'", "").replace("?", "");
	 
	     if (s.endsWith(".")) s = s.substring(0, s.length() - 1);
	     if ((s.contains(".")) || (s.contains("@")) || (s.contains("&")) || 
	       (s.contains("[")) || (s.contains("]")) || (s.contains("\\")) || 
	       (s.contains("~")) || (s.contains("{")) || (s.contains("}")) || 
	       (s.contains("`")) || (s.contains("|")) || (s.contains("\t"))) {
	    	 s = "";
	     }
	 
	     for (int i = 0; i <= 9; i++) {
	       if (s.contains(i + "")) s = "";
	       if (s.contains("$")) s = "";
	     }
	 
	     return s;
	   }
	 

	public ArrayList<TDocument> getDocs() {
		return docs;
	}

	public void setDocs(ArrayList<TDocument> docs) {
		this.docs = docs;
	}

	public int getNumberofDocs() {
		return numberofDocs;
	}

	public void setNumberofDocs(int numberofDocs) {
		this.numberofDocs = numberofDocs;
	}

	public int getNumberofTerms() {
		return numberofTerms;
	}

	public void setNumberofTerms(int numberofTerms) {
		this.numberofTerms = numberofTerms;
	}	
}
