package common.sis.pitt.edu;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Read file content to ArrayList<String>
 * @author shuguang
 *
 */
public class Reader {
	
	public Reader(){
		
	}
	
	public static ArrayList<String> read(String filename){
		ArrayList<String> lineList = new ArrayList<String>();
		
		try {
			FileInputStream fis = new FileInputStream(filename);
			InputStreamReader Inputreader = new InputStreamReader(fis,"utf-8");
			BufferedReader br = new BufferedReader(Inputreader);		
			String line = new String();
			while((line = br.readLine()) != null)	
			{
				lineList.add(line);
			}
			br.close();
			Inputreader.close();
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return lineList;
	}
	
	public static String read(String filename, String type){
		StringBuilder sb = new StringBuilder("");
		
		try {
			FileInputStream fis = new FileInputStream(filename);
			InputStreamReader Inputreader = new InputStreamReader(fis,"utf-8");
			BufferedReader br = new BufferedReader(Inputreader);		
			String line = new String();
			while((line = br.readLine()) != null)	
			{
				sb.append(line + " ");
			}
			br.close();
			Inputreader.close();
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return sb.toString();
	}
	
	public static String readurl(String query){
		StringBuilder sb = new StringBuilder("");
		
		try {
			URL url = new URL(query);
			 URLConnection connection = url.openConnection();
		   
		    connection.setConnectTimeout(12000);
		    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1");
		    connection.setRequestProperty("Accept", "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, application/xaml+xml, application/vnd.ms-xpsdocument, application/x-ms-xbap, application/x-ms-application, */*");
		    connection.setRequestProperty("Accept-Language", "zh-cn");
		    connection.setRequestProperty("Accept-Encoding", "deflate");
		    connection.setRequestProperty("Accept-Charset", "null");
		    connection.setRequestProperty("Connection", "Keep-Alive");
		    
		    
		    connection.connect();
		    InputStream ism = connection.getInputStream();
		    Scanner in = new Scanner(ism, "utf-8");
			while (in.hasNextLine()){
				sb.append(in.nextLine());
			}
			
		} catch (IOException e) {			
			e.printStackTrace();
		}
		
		return sb.toString();
	}

	
}
